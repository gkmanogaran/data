import { RenderMode, ServerRoute } from '@angular/ssr';

export const serverRoutes: ServerRoute[] = [
  {
    path: '', 
    renderMode: RenderMode.Server
  },
  {
    path: 'api/users',
    renderMode: RenderMode.Server,
    serverRoute: './src/app/api/users.server.ts' 
  }
];
