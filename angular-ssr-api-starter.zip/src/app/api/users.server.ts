import { Request, Response } from 'express';

export async function GET(req: Request, res: Response) {
  try {
    const mockDbData = [
      { id: 1, name: 'Alice' },
      { id: 2, name: 'Bob' },
      { id: 3, name: 'Charlie' }
    ];

    res.status(200).json(mockDbData);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch database records' });
  }
}
