import { Component, inject, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-home',
  standalone: true,
  template: `
    <div style="font-family: sans-serif; padding: 2rem; max-width: 600px; margin: 0 auto; background: #f9f9f9; border-radius: 8px;">
      <h1 style="color: #dd0031;">Angular SSR Unified Architecture</h1>
      <p>This layout functions identically to Next.js API routing. The data below is fetched via relative path execution on the server engine.</p>
      
      <h2>User Directory</h2>
      <ul style="list-style-type: none; padding: 0;">
        @for (user of users; track user.id) {
          <li style="padding: 0.5rem; margin-bottom: 0.5rem; background: #fff; border: 1px solid #ddd; border-radius: 4px;">
            <strong>ID:</strong> {{ user.id }} | <strong>Name:</strong> {{ user.name }}
          </li>
        } @empty {
          <li>Loading user records...</li>
        }
      </ul>
    </div>
  `
})
export class HomeComponent implements OnInit {
  private http = inject(HttpClient);
  protected users: any[] = [];

  ngOnInit() {
    this.http.get<any[]>('/api/users').subscribe({
      next: (data) => this.users = data,
      error: (err) => console.error('Failed to resolve server route API:', err)
    });
  }
}
